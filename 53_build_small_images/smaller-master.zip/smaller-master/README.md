# smaller
Examples from "Building Smaller Images" Lesson
